# StockAI India — ML Engineer Package

This IT-only package is based on the supplied categorized company workbook (9,097 source rows). The included `data/master/companies_master.csv` is filtered to the exact source category `Information Technology (IT)` and contains 126 exchange/security records representing 76 unique ISINs. The supplied ZIP is **not** a complete export of the existing Drive project: it contains a checkpoint README and two excerpts, not the complete source tree, datasets, notebook cells, or model binaries. This package does not claim to have audited unseen files or integrated the legacy model.

## Features
- Company search by name/ticker with a Streamlit dashboard.
- Incremental/resumable Yahoo Finance historical-price cache.
- Technical features, next-observed-session close regression, chronological holdout MAE/RMSE.
- Company-news retrieval through Google News RSS and a transparent lexicon sentiment baseline.
- BUY/SELL/HOLD classification using documented configurable return thresholds.
- Batch market update and batch prediction CSV outputs.
- Google Colab notebook for setup and running.

## Run
```bash
pip install -r requirements.txt
streamlit run app/streamlit_app.py
python -m unittest discover -s tests -v
python -m scripts.batch_predict --refresh --news
```
Upload `notebooks/colab_setup_and_run.ipynb` to Colab and upload this ZIP to `/content/StockAI_India_IT_Only_Package.zip`. The notebook copies this IT-only project to `/content/drive/MyDrive/stock_market_ai_india_cloud/stockai_it_only_package`, keeping the older project folder separate.

## Important limitations
- No model can guarantee 100% correct predictions or 100% data coverage.
- A company-master row is not proof that a security is currently active/tradable or has a supported price history.
- Prices come from Yahoo Finance, not an official exchange feed; coverage, timing, mapping and licensing may vary.
- New listings without history remain searchable but are marked unavailable for time-series forecasting; prices are never invented.
- Sentiment is a simple lexicon baseline, not a validated financial NLP model. In this baseline it modestly affects the decision score; it is not claimed to be a learned causal price effect.
- Colab runtimes disconnect. The notebook does not establish unattended daily scheduling.
- Forecasts and BUY/SELL/HOLD labels are research outputs, not financial advice or trading orders.

## Full universe
The included `data/master/companies_master.csv` is the IT-only master extracted from the supplied categorized file. It has 126 exchange/security records (51 NSE and 75 BSE) and 76 unique ISINs. All source rows in the exact `Information Technology (IT)` category are preserved. A row is not proof that a security is active/tradable or that Yahoo Finance has price history. The batch prediction command with `--refresh --news` processes the whole loaded IT master without a row limit, attempts to refresh prices, retrieves available Google News RSS items, calculates a baseline sentiment score, and writes timestamped and latest prediction CSVs. Network/provider availability and rate limits can cause missing results; review each row status. Sentiment is a simple word-lexicon baseline, not a validated financial NLP model.

## Legacy model
The checkpoint reports an existing direction model expecting 38 features while the newer feature output had 39 columns. This package intentionally does not load the old model. Resolve schema and training metadata from the full project before integrating it.

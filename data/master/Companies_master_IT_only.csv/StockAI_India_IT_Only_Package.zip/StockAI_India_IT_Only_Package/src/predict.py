from datetime import datetime,timezone
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error,mean_squared_error
from .features import FEATURES,training_frame,features
from .config import MIN_ROWS,TEST_FRACTION,BUY_THRESHOLD,SELL_THRESHOLD
def decision(r):
    return "BUY" if r>=BUY_THRESHOLD else "SELL" if r<=SELL_THRESHOLD else "HOLD"
def predict(raw,sentiment_score=0.0):
    f=training_frame(raw)
    if len(f)<MIN_ROWS: return {"status":"INSUFFICIENT_HISTORY","message":f"Need {MIN_ROWS} usable rows; got {len(f)}."}
    X=f[FEATURES].replace([np.inf,-np.inf],np.nan); y=f.target_next_close
    split=max(int(len(f)*(1-TEST_FRACTION)),MIN_ROWS)
    if split>=len(f): split=len(f)-1
    if split<60: return {"status":"INSUFFICIENT_HISTORY","message":"Not enough chronological holdout rows."}
    model=Pipeline([("imputer",SimpleImputer(strategy="median")),("model",HistGradientBoostingRegressor(
        max_iter=160,learning_rate=.06,max_leaf_nodes=15,l2_regularization=1.0,random_state=42))])
    model.fit(X.iloc[:split],y.iloc[:split]); test_pred=model.predict(X.iloc[split:])
    mae=float(mean_absolute_error(y.iloc[split:],test_pred)); rmse=float(np.sqrt(mean_squared_error(y.iloc[split:],test_pred)))
    model.fit(X,y)
    latest=features(raw).dropna(subset=FEATURES)
    if latest.empty: return {"status":"INSUFFICIENT_FEATURES","message":"Latest features are incomplete."}
    r=latest.iloc[-1]; actual=float(r.close); forecast=float(model.predict(latest[FEATURES].iloc[[-1]])[0])
    model_ret=forecast/actual-1 if actual else 0
    adjusted=model_ret+0.0025*float(sentiment_score)
    return {"status":"OK","latest_actual_close":actual,"latest_market_date":str(r.date.date()),
        "predicted_next_close":forecast,"predicted_change":forecast-actual,"model_expected_return_pct":model_ret*100,
        "sentiment_score":float(sentiment_score),"sentiment_adjusted_return_pct":adjusted*100,"decision":decision(adjusted),
        "mae_holdout":mae,"rmse_holdout":rmse,"holdout_rows":len(X)-split,"training_rows":len(X),
        "model":"HistGradientBoostingRegressor","feature_schema_version":"stockai-features-v1",
        "prediction_timestamp_utc":datetime.now(timezone.utc).isoformat(),
        "warning":"Research estimate. Sentiment is a small heuristic overlay, not a learned causal effect or financial advice."}

import numpy as np
import pandas as pd
FEATURES=["return_1d","return_5d","return_10d","ma_ratio_5","ma_ratio_20","ma_ratio_50",
"volatility_10","volatility_20","rsi_14","macd","macd_signal","volume_change","volume_ratio","range_pct","body_pct"]
def features(raw):
    if raw is None or raw.empty: return pd.DataFrame()
    d=raw.copy()
    if isinstance(d.columns,pd.MultiIndex): d.columns=[c[0] for c in d.columns]
    d.columns=[str(c).strip().lower().replace(" ","_") for c in d.columns]
    if "date" not in d:
        d=d.reset_index(); d.columns=[str(c).strip().lower().replace(" ","_") for c in d.columns]
    req={"open","high","low","close","volume"}
    if not req.issubset(d.columns): raise ValueError(f"Missing price fields: {req-set(d.columns)}")
    d["date"]=pd.to_datetime(d["date"],errors="coerce")
    for c in req: d[c]=pd.to_numeric(d[c],errors="coerce")
    d=d.dropna(subset=["date","open","high","low","close"]).sort_values("date").drop_duplicates("date",keep="last").reset_index(drop=True)
    c=d.close; v=d.volume.replace(0,np.nan); ret=c.pct_change()
    d["return_1d"]=ret; d["return_5d"]=c.pct_change(5); d["return_10d"]=c.pct_change(10)
    for n in [5,20,50]: d[f"ma_ratio_{n}"]=c/c.rolling(n).mean()-1
    d["volatility_10"]=ret.rolling(10).std(); d["volatility_20"]=ret.rolling(20).std()
    delta=c.diff(); gain=delta.clip(lower=0).rolling(14).mean(); loss=(-delta.clip(upper=0)).rolling(14).mean()
    d["rsi_14"]=100-100/(1+gain/loss.replace(0,np.nan))
    d["macd"]=c.ewm(span=12,adjust=False).mean()-c.ewm(span=26,adjust=False).mean()
    d["macd_signal"]=d.macd.ewm(span=9,adjust=False).mean()
    d["volume_change"]=v.pct_change(); d["volume_ratio"]=v/v.rolling(20).mean()
    d["range_pct"]=(d.high-d.low)/c.replace(0,np.nan); d["body_pct"]=(d.close-d.open)/d.open.replace(0,np.nan)
    d[FEATURES]=d[FEATURES].replace([np.inf,-np.inf],np.nan)
    return d
def training_frame(raw):
    d=features(raw)
    if d.empty: return d
    d["target_next_close"]=d.close.shift(-1)
    d["target_next_return"]=d.target_next_close/d.close-1
    return d.dropna(subset=FEATURES+["target_next_close","target_next_return"]).reset_index(drop=True)

import re
from datetime import datetime,timezone
import feedparser,pandas as pd
from urllib.parse import quote_plus
from .config import NEWS
POS={"beat","growth","profit","upgrade","surge","record","strong","gain","bullish","buyback","expansion","wins","positive","recovery","improve","outperform"}
NEG={"loss","miss","downgrade","fraud","probe","investigation","decline","fall","drop","weak","bearish","default","debt","crisis","penalty","lawsuit","negative","warning","cut","resign"}
def score(text):
    words=re.findall(r"[a-z]+",(text or "").lower()); p=sum(w in POS for w in words); n=sum(w in NEG for w in words)
    val=(p-n)/max(1,p+n); label="positive" if val>.1 else "negative" if val<-.1 else "neutral"
    return float(val),label
def fetch(name,limit=25):
    url="https://news.google.com/rss/search?q="+quote_plus(f'"{name}" stock India')+"&hl=en-IN&gl=IN&ceid=IN:en"
    feed=feedparser.parse(url); rows=[]
    for e in feed.entries[:limit]:
        title=str(getattr(e,"title","")); summary=re.sub("<[^>]+>"," ",str(getattr(e,"summary","")))
        val,label=score(title+" "+summary)
        rows.append({"title":title,"summary":summary,"published":getattr(e,"published",""),"sentiment_score":val,
                     "sentiment_label":label,"source_url":getattr(e,"link","")})
    df=pd.DataFrame(rows)
    if not df.empty:
        stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        safe=re.sub(r"[^A-Za-z0-9_-]+","_",name); df.to_csv(NEWS/f"{safe}_{stamp}.csv",index=False)
    return df
def aggregate(df):
    if df is None or df.empty: return {"sentiment_score":0.0,"sentiment_label":"unavailable","news_count":0,
        "sentiment_status":"No news retrieved; zero is a fallback, not proof of neutral sentiment"}
    avg=float(pd.to_numeric(df.sentiment_score,errors="coerce").dropna().mean())
    label="positive" if avg>.1 else "negative" if avg<-.1 else "neutral"
    return {"sentiment_score":avg,"sentiment_label":label,"news_count":len(df),"sentiment_status":"Simple word-lexicon baseline"}

import argparse,json,time
from datetime import datetime,timezone
import pandas as pd
from src.universe import load_master,provider_symbol
from src.market_data import update
from src.config import LOGS
def main():
    p=argparse.ArgumentParser(); p.add_argument("--limit",type=int,default=0); p.add_argument("--delay",type=float,default=.4); a=p.parse_args()
    m=load_master()
    if a.limit>0: m=m.head(a.limit)
    out=[]
    for i,(_,r) in enumerate(m.iterrows(),1):
        s=provider_symbol(r)
        try: result=update(s)
        except Exception as e: result={"symbol":s,"status":"FAILED","rows":0,"error":str(e)}
        result.update({"company_name":r.company_name,"exchange":r.exchange}); out.append(result)
        print(f"[{i}/{len(m)}] {s}: {result['status']}"); time.sleep(max(0,a.delay))
    d=pd.DataFrame(out); stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    d.to_csv(LOGS/f"market_update_{stamp}.csv",index=False); d.to_csv(LOGS/"market_update_latest.csv",index=False)
    summary={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"requested":len(m),
        "updated":int(d.status.eq("UPDATED").sum()),"failed":int(d.status.eq("FAILED").sum()),
        "no_data_or_symbol":int(d.status.isin(["NO_NEW_DATA","NO_SYMBOL"]).sum())}
    (LOGS/"market_update_summary_latest.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=="__main__": main()

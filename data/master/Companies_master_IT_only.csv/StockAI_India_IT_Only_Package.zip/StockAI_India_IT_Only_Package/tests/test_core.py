import unittest
import numpy as np,pandas as pd
from src.features import features,FEATURES
from src.predict import decision
class CoreTests(unittest.TestCase):
 def test_feature_columns(self):
  rng=np.random.default_rng(3); n=220; c=100*np.cumprod(1+rng.normal(0,.01,n))
  d=pd.DataFrame({"Date":pd.bdate_range("2020-01-01",periods=n),"Open":c*.999,"High":c*1.01,"Low":c*.99,"Close":c,"Volume":rng.integers(100,10000,n)})
  out=features(d); self.assertTrue(set(FEATURES).issubset(out.columns)); self.assertEqual(len(out),n)
 def test_signal_thresholds(self):
  self.assertEqual(decision(.02),"BUY"); self.assertEqual(decision(-.02),"SELL"); self.assertEqual(decision(0),"HOLD")
if __name__=="__main__": unittest.main()

```
================== SCRIPT LINES 1020-1230 ==================
1020:     print("[NIFTY] Rows:", len(combined))
1021: 
1022: 
1023: def main():
1024: 
1025: 
1026:     # Update NIFTY benchmark before company features
1027:     update_nifty_benchmark()
1028: 
1029: 
1030:     started = datetime.now()
1031: 
1032:     print("=" * 70)
1033:     print(
1034:         "STAGE 2 - AUTOMATIC MARKET DATA UPDATE"
1035:     )
1036:     print("=" * 70)
1037: 
1038:     print(
1039:         f"Started: "
1040:         f"{started.isoformat()}"
1041:     )
1042: 
1043:     print(
1044:         f"Project: "
1045:         f"{ROOT}"
1046:     )
1047: 
1048:     # --------------------------------------------------------
1049:     # LOAD MASTER
1050:     # --------------------------------------------------------
1051: 
1052:     master = load_master()
1053: 
1054:     print(
1055:         f"\nMaster securities available: "
1056:         f"{len(master)}"
1057:     )
1058: 
1059:     # --------------------------------------------------------
1060:     # TEST OR FULL MODE
1061:     # --------------------------------------------------------
1062: 
1063:     if TEST_MODE:
1064: 
1065:         working = master.head(
1066:             TEST_LIMIT
1067:         ).copy()
1068: 
1069:         print(
1070:             "\nMODE: TEST"
1071:         )
1072: 
1073:         print(
1074:             f"Processing: "
1075:             f"{len(working)} securities"
1076:         )
1077: 
1078:     else:
1079: 
1080:         working = master.copy()
1081:         coverage_file = ROOT / "data" / "master" / "data_coverage.csv"
1082:         skipped_known_no_data = 0
1083: 
1084:         # Avoid repeatedly requesting securities already known to
1085:         # have no Yahoo Finance data. Keep new/unlisted-in-coverage
1086:         # securities and all other statuses eligible for processing.
1087:         if coverage_file.exists():
1088:             try:
1089:                 coverage = pd.read_csv(coverage_file)
1090:                 coverage.columns = [
1091:                     str(c).strip().lower() for c in coverage.columns
1092:                 ]
1093: 
1094:                 if {"yahoo_symbol", "status"}.issubset(coverage.columns):
1095:                     known_no_data = set(
1096:                         coverage.loc[
1097:                             coverage["status"].astype(str).str.upper()
1098:                             .eq("YAHOO_NO_DATA"),
1099:                             "yahoo_symbol"
1100:                         ].dropna().astype(str).str.strip()
1101:                     )
1102: 
1103:                     before_count = len(working)
1104:                     working = working[
1105:                         ~working["yahoo_symbol"].astype(str).str.strip()
1106:                         .isin(known_no_data)
1107:                     ].copy()
1108:                     skipped_known_no_data = before_count - len(working)
1109: 
1110:             except Exception as exc:
1111:                 print(
1112:                     f"[WARNING] Could not apply no-data skip: {exc}",
1113:                     flush=True,
1114:                 )
1115:                 working = master.copy()
1116: 
1117:         print(
1118:             f"Known Yahoo-no-data securities skipped today: "
1119:             f"{skipped_known_no_data}",
1120:             flush=True,
1121:         )
1122: 
1123:         print(
1124:             "\nMODE: INCREMENTAL PRODUCTION"
1125:         )
1126: 
1127:         print(
1128:             f"Processing: "
1129:             f"{len(working)} securities"
1130:         )
1131: 
1132:     print(
1133:         "\nStarting market-data processing..."
1134:     )
1135: 
1136:     # --------------------------------------------------------
1137:     # PROCESS
1138:     # --------------------------------------------------------
1139: 
1140:     results = []
1141: 
1142:     total = len(working)
1143: 
1144:     fast_skipped_current = 0
1145:     for position, (_, row) in enumerate(
1146:         working.iterrows(),
1147:         start=1
1148:     ):
1149: 
1150:         print(
1151:             "\n"
1152:             + "-" * 70
1153:         )
1154: 
1155:         print(
1156:             f"PROGRESS: "
1157:             f"{position}/{total}"
1158:         )
1159: 
1160:         try:
1161: 
1162:             # FAST SKIP: raw data is already updated for today
1163:             symbol = str(row["yahoo_symbol"]).strip()
1164:             raw_file = ROOT / "data" / "raw" / f"{symbol}.csv"
1165:             if raw_file.exists():
1166:                 try:
1167:                     dates = pd.read_csv(raw_file, usecols=["Date"])["Date"]
1168:                     latest = pd.to_datetime(dates, errors="coerce").max()
1169:                     if pd.notna(latest) and latest.date() >= pd.Timestamp.now().date():
1170:                         fast_skipped_current += 1
1171:                         continue
1172:                 except Exception:
1173:                     pass
1174:             result = process_security(
1175:                 row
1176:             )
1177: 
1178:         except Exception as exc:
1179: 
1180:             result = {
1181:                 "status": "FAILED",
1182:                 "symbol": row["yahoo_symbol"],
1183:                 "exchange": row["exchange"],
1184:                 "company_name": row["company_name"],
1185:                 "old_rows": 0,
1186:                 "new_rows": 0,
1187:                 "total_rows": 0,
1188:                 "latest_date": None,
1189:                 "error": str(exc)
1190:             }
1191: 
1192:             print(
1193:                 f"[FAILED] "
1194:                 f"{row['yahoo_symbol']}: "
1195:                 f"{exc}"
1196:             )
1197: 
1198:         results.append(
1199:             result
1200:         )
1201: 
1202:         # Small delay between securities.
1203:         time.sleep(
1204:             REQUEST_DELAY_SECONDS
1205:             +
1206:             random.uniform(
1207:                 0,
1208:                 RANDOM_DELAY_SECONDS
1209:             )
1210:         )
1211: 
1212:     # --------------------------------------------------------
1213:     # SAVE REPORTS
1214:     # --------------------------------------------------------
1215: 
1216:     (
1217:         results_df,
1218:         summary,
1219:         result_file,
1220:         summary_file
1221:     ) = save_reports(
1222:         results
1223:     )
1224: 
1225:     finished = datetime.now()
1226: 
1227:     elapsed = (
1228:         finished -
1229:         started
1230:     ).total_seconds()

================== SCRIPT LINES 1270-1335 ==================
1270: 
1271:     print(
1272:         f"No New Data    : {summary['no_new_data']}"
1273:     )
1274: 
1275:     print(
1276:         f"Failed         : {summary['failed']}"
1277:     )
1278: 
1279:     print(
1280:         "\nDetailed report:"
1281:     )
1282: 
1283:     print(
1284:         result_file
1285:     )
1286: 
1287:     print(
1288:         "\nLatest summary:"
1289:     )
1290: 
1291:     print(
1292:         summary_file
1293:     )
1294: 
1295:     print("=" * 70)
1296: 
1297:     # --------------------------------------------------------
1298:     # FAILED SECURITY LIST
1299:     # --------------------------------------------------------
1300: 
1301:     failed = results_df[
1302:         results_df["status"] == "FAILED"
1303:     ]
1304: 
1305:     if not failed.empty:
1306: 
1307:         failed_file = (
1308:             LOG_DIR /
1309:             "market_data_failed_latest.csv"
1310:         )
1311: 
1312:         failed.to_csv(
1313:             failed_file,
1314:             index=False
1315:         )
1316: 
1317:         print(
1318:             "\nWARNING:"
1319:         )
1320: 
1321:         print(
1322:             f"{len(failed)} securities failed."
1323:         )
1324: 
1325:         print(
1326:             f"Failure report:"
1327:         )
1328: 
1329:         print(
1330:             failed_file
1331:         )
1332: 
1333:     else:
1334: 
1335:         print(

=== LATEST MARKET-DATA REPORT ===
{
  "timestamp": "2026-09-29T17:35:57.331677",
  "processed": 3493,
  "initialized": 0,
  "updated": 3076,
  "up_to_date": 0,
  "no_new_data": 417,
  "failed": 0,
  "result_file": "/content/drive/MyDrive/stocks/stock_market_ai_india_cloud/outputs/logs/market_data_update_20260929_173557.csv"
}

=== CHECKPOINT FILE ===
Modified: 2026-09-24 13:43:06
Size: 1132493 bytes
Rows: 9070 | Columns: ['timestamp', 'company_name', 'exchange', 'symbol', 'bse_code', 'isin', 'yahoo_symbol', 'status', 'new_rows', 'total_rows', 'latest_date', 'elapsed_seconds', 'error']
                 timestamp                 company_name exchange     symbol  bse_code         isin  yahoo_symbol               status  new_rows  total_rows latest_date  elapsed_seconds  error
2026-09-24T13:42:53.441622      KRISHIVAL FOODS LIMITED      BSE    KRISHPP  890232.0 IN90GGO01013    KRISHPP.BO              UPDATED        53         123  2026-09-23             0.45    NaN
2026-09-24T13:42:54.227643            PVV Infra Limited      BSE     PVVIPP  890233.0 IN9428B01029     PVVIPP.BO INSUFFICIENT_HISTORY        30          30  2026-09-23             0.17    NaN
2026-09-24T13:42:55.283120       Vertex Securities Ltd.      BSE   VERTEXPP  890234.0 IN9316D01014   VERTEXPP.BO              UPDATED         4         116  2026-09-24             0.41    NaN
2026-09-24T13:42:56.474949          BCC Fuba India Ltd.      BSE      BCCPP  890235.0 IN9788D01014      BCCPP.BO              UPDATED       101         120  2026-09-23             0.58    NaN
2026-09-24T13:42:57.341898        Prabha Energy Limited      BSE   PRABHAPP  890236.0 IN90I0M01022   PRABHAPP.BO              NO_DATA         0           0         NaN             0.25    NaN
2026-09-24T13:42:58.454675                     TIL Ltd.      BSE      TILPP  890237.0 IN9806C01016      TILPP.BO              UPDATED        81         106  2026-09-23             0.46    NaN
2026-09-24T13:42:59.552829 G.S. Auto International Ltd.      BSE    GSAILPP  890238.0 IN9736H01014    GSAILPP.BO              UPDATED         4          70  2026-09-24             0.43    NaN
2026-09-24T13:43:00.469935   Mold-Tek Packaging Limited      BSE MOLDTKWARR  961913.0 INE893J13016 MOLDTKWARR.BO              NO_DATA         0           0         NaN             0.25    NaN

```
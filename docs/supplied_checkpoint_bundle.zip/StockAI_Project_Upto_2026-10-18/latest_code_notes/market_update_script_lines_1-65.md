```
=== LINES 1-65 ===
1: 
2: from pathlib import Path
3: from datetime import datetime, timedelta
4: import time
5: import json
6: import random
7: 
8: import pandas as pd
9: import yfinance as yf
10: 
11: 
12: # ============================================================
13: # PROJECT PATHS
14: # ============================================================
15: 
16: ROOT = Path(
17:     "/content/drive/MyDrive/stocks/stock_market_ai_india_cloud"
18: )
19: 
20: MASTER_FILE = (
21:     ROOT / "data" / "master" / "companies_master.csv"
22: )
23: 
24: RAW_DIR = (
25:     ROOT / "data" / "raw"
26: )
27: 
28: LOG_DIR = (
29:     ROOT / "outputs" / "logs"
30: )
31: 
32: RAW_DIR.mkdir(
33:     parents=True,
34:     exist_ok=True
35: )
36: 
37: LOG_DIR.mkdir(
38:     parents=True,
39:     exist_ok=True
40: )
41: 
42: 
43: # ============================================================
44: # CONFIGURATION
45: # ============================================================
46: 
47: # FULL PRODUCTION MODE
48: TEST_MODE = False
49: 
50: # Number of securities in test mode.
51: TEST_LIMIT = 10
52: 
53: # Initial history for a newly discovered security.
54: INITIAL_HISTORY_YEARS = 5
55: 
56: # Retry temporary Yahoo/network failures.
57: MAX_RETRIES = 3
58: 
59: # Pause between requests.
60: REQUEST_DELAY_SECONDS = 0.5
61: 
62: # Extra randomized delay.
63: RANDOM_DELAY_SECONDS = 0.3
64: 
65: 

=== LINES 440-510 ===
440:         pd.DataFrame(),
441:         last_error
442:     )
443: 
444: 
445: # ============================================================
446: # MERGE DATA
447: # ============================================================
448: 
449: def merge_and_save(
450:     existing,
451:     new_data,
452:     output_file
453: ):
454: 
455:     if existing.empty:
456: 
457:         combined = new_data.copy()
458: 
459:     elif new_data.empty:
460: 
461:         combined = existing.copy()
462: 
463:     else:
464: 
465:         combined = pd.concat(
466:             [
467:                 existing,
468:                 new_data
469:             ],
470:             ignore_index=True
471:         )
472: 
473:     if combined.empty:
474: 
475:         return combined
476: 
477:     combined["Date"] = pd.to_datetime(
478:         combined["Date"],
479:         errors="coerce"
480:     )
481: 
482:     combined = combined.dropna(
483:         subset=[
484:             "Date"
485:         ]
486:     )
487: 
488:     combined = combined.drop_duplicates(
489:         subset=[
490:             "Date"
491:         ],
492:         keep="last"
493:     )
494: 
495:     combined = combined.sort_values(
496:         "Date"
497:     )
498: 
499:     combined.to_csv(
500:         output_file,
501:         index=False
502:     )
503: 
504:     return combined.reset_index(
505:         drop=True
506:     )
507: 
508: 
509: # ============================================================
510: # PROCESS ONE SECURITY

=== LINES 510-720 ===
510: # PROCESS ONE SECURITY
511: # ============================================================
512: 
513: def process_security(row):
514: 
515:     symbol = row["yahoo_symbol"]
516: 
517:     exchange = row["exchange"]
518: 
519:     company_name = row["company_name"]
520: 
521:     output_file = get_output_file(
522:         symbol
523:     )
524: 
525:     existing = load_existing_data(
526:         output_file
527:     )
528: 
529:     today = datetime.now().date()
530: 
531:     # --------------------------------------------------------
532:     # NEW SECURITY
533:     # --------------------------------------------------------
534: 
535:     if existing.empty:
536: 
537:         start_date = (
538:             today -
539:             timedelta(
540:                 days=365 *
541:                 INITIAL_HISTORY_YEARS
542:             )
543:         )
544: 
545:         print(
546:             f"[INITIAL] "
547:             f"{exchange} | "
548:             f"{symbol} | "
549:             f"{company_name}"
550:         )
551: 
552:         new_data, error = (
553:             download_from_yahoo(
554:                 symbol,
555:                 start_date,
556:                 today +
557:                 timedelta(days=1)
558:             )
559:         )
560: 
561:         if new_data.empty:
562: 
563:             return {
564:                 "status": "FAILED",
565:                 "symbol": symbol,
566:                 "exchange": exchange,
567:                 "company_name": company_name,
568:                 "old_rows": 0,
569:                 "new_rows": 0,
570:                 "total_rows": 0,
571:                 "latest_date": None,
572:                 "error": (
573:                     error
574:                     or
575:                     "No historical data returned"
576:                 )
577:             }
578: 
579:         combined = merge_and_save(
580:             existing,
581:             new_data,
582:             output_file
583:         )
584: 
585:         latest_date = (
586:             combined["Date"].max()
587:         )
588: 
589:         return {
590:             "status": "INITIALIZED",
591:             "symbol": symbol,
592:             "exchange": exchange,
593:             "company_name": company_name,
594:             "old_rows": 0,
595:             "new_rows": len(new_data),
596:             "total_rows": len(combined),
597:             "latest_date": latest_date.strftime(
598:                 "%Y-%m-%d"
599:             ),
600:             "error": None
601:         }
602: 
603:     # --------------------------------------------------------
604:     # EXISTING SECURITY
605:     # --------------------------------------------------------
606: 
607:     last_date = (
608:         existing["Date"].max()
609:     ).date()
610: 
611:     print(
612:         f"[CHECK] "
613:         f"{exchange} | "
614:         f"{symbol} | "
615:         f"last={last_date}"
616:     )
617: 
618:     # If the data is already from today or later,
619:     # no request is needed.
620:     if last_date >= today:
621: 
622:         return {
623:             "status": "UP_TO_DATE",
624:             "symbol": symbol,
625:             "exchange": exchange,
626:             "company_name": company_name,
627:             "old_rows": len(existing),
628:             "new_rows": 0,
629:             "total_rows": len(existing),
630:             "latest_date": last_date.strftime(
631:                 "%Y-%m-%d"
632:             ),
633:             "error": None
634:         }
635: 
636:     start_date = (
637:         last_date +
638:         timedelta(days=1)
639:     )
640: 
641:     new_data, error = (
642:         download_from_yahoo(
643:             symbol,
644:             start_date,
645:             today +
646:             timedelta(days=1)
647:         )
648:     )
649: 
650:     # --------------------------------------------------------
651:     # NO NEW MARKET DATA
652:     # --------------------------------------------------------
653: 
654:     if new_data.empty:
655: 
656:         return {
657:             "status": "NO_NEW_DATA",
658:             "symbol": symbol,
659:             "exchange": exchange,
660:             "company_name": company_name,
661:             "old_rows": len(existing),
662:             "new_rows": 0,
663:             "total_rows": len(existing),
664:             "latest_date": last_date.strftime(
665:                 "%Y-%m-%d"
666:             ),
667:             "error": (
668:                 error
669:                 or
670:                 "No newer market rows returned"
671:             )
672:         }
673: 
674:     # --------------------------------------------------------
675:     # MERGE
676:     # --------------------------------------------------------
677: 
678:     combined = merge_and_save(
679:         existing,
680:         new_data,
681:         output_file
682:     )
683: 
684:     latest_date = (
685:         combined["Date"].max()
686:     )
687: 
688:     actual_new_rows = max(
689:         0,
690:         len(combined) -
691:         len(existing)
692:     )
693: 
694:     if actual_new_rows == 0:
695: 
696:         status = "NO_NEW_DATA"
697: 
698:     else:
699: 
700:         status = "UPDATED"
701: 
702:     return {
703:         "status": status,
704:         "symbol": symbol,
705:         "exchange": exchange,
706:         "company_name": company_name,
707:         "old_rows": len(existing),
708:         "new_rows": actual_new_rows,
709:         "total_rows": len(combined),
710:         "latest_date": latest_date.strftime(
711:             "%Y-%m-%d"
712:         ),
713:         "error": None
714:     }
715: 
716: 
717: # ============================================================
718: # SAVE REPORT
719: # ============================================================
720: 

=== LINES 1330-1370 ===
1330:             failed_file
1331:         )
1332: 
1333:     else:
1334: 
1335:         print(
1336:             "\nNo securities failed."
1337:         )
1338: 
1339:     print(
1340:         "\nStage 2 finished successfully."
1341:     )
1342: 
1343:     print("=" * 70)
1344: 
1345: 
1346: if __name__ == "__main__":
1347:     import argparse
1348: 
1349:     parser = argparse.ArgumentParser(description="Update stock market data safely.")
1350:     parser.add_argument("--test", action="store_true",
1351:                         help="Run in limited test mode (requires TEST_MODE support).")
1352:     parser.add_argument("--limit", type=int, default=5,
1353:                         help="Maximum securities in test mode (default: 5).")
1354:     args = parser.parse_args()
1355: 
1356:     if args.limit < 1:
1357:         parser.error("--limit must be at least 1")
1358: 
1359:     if args.test:
1360:         globals()["TEST_MODE"] = True
1361:         globals()["TEST_LIMIT"] = args.limit
1362: 
1363:     main()

=== CLI HELP ===
usage: update_market_data.py [-h] [--test] [--limit LIMIT]

Update stock market data safely.

options:
  -h, --help     show this help message and exit
  --test         Run in limited test mode (requires TEST_MODE support).
  --limit LIMIT  Maximum securities in test mode (default: 5).

Exit code: 0

```

import argparse
import re
from datetime import datetime, timezone

import pandas as pd

from src.universe import load_master, provider_symbol
from src.market_data import history
from src.sentiment import fetch, aggregate
from src.predict import predict
from src.config import PRED


def is_rights_entitlement(ticker):
    """Match rights-entitlement tickers ending in -RE, -RE1, -RE2, etc."""
    return bool(
        re.search(
            r"-RE\d*$",
            str(ticker).strip(),
            flags=re.IGNORECASE,
        )
    )


def main():
    parser = argparse.ArgumentParser(
        description="Generate predictions for the IT company master."
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Process only the first N master records; 0 means all.",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Refresh market history before predicting.",
    )
    parser.add_argument(
        "--news",
        action="store_true",
        help="Fetch news sentiment for each eligible company.",
    )
    args = parser.parse_args()

    if args.limit < 0:
        parser.error("--limit must be zero or a positive integer")

    master = load_master()

    if args.limit > 0:
        master = master.head(args.limit)

    PRED.mkdir(parents=True, exist_ok=True)

    results = []
    total = len(master)

    for index, (_, company) in enumerate(master.iterrows(), start=1):
        name = str(company.get("company_name", ""))
        exchange = str(company.get("exchange", ""))
        ticker = str(company.get("ticker", ""))
        symbol = provider_symbol(company)

        base = {
            "company_name": name,
            "exchange": exchange,
            "ticker": ticker,
            "provider_symbol": symbol,
        }

        if is_rights_entitlement(ticker):
            result = {
                **base,
                "status": "SKIPPED_NON_ORDINARY_SECURITY",
                "message": (
                    "Rights-entitlement security; ordinary-share "
                    "prediction skipped."
                ),
            }
            results.append(result)
            print(
                f"[{index}/{total}] {name}: "
                "SKIPPED_NON_ORDINARY_SECURITY"
            )
            continue

        try:
            prices = history(symbol, refresh=args.refresh) if symbol else pd.DataFrame()

            if prices.empty:
                result = {
                    **base,
                    "status": "NO_PRICE_HISTORY",
                    "message": (
                        "No local price history is available. "
                        "Provider coverage and listing status are unverified."
                    ),
                    "raw_history_rows": 0,
                }
            else:
                if args.news:
                    sentiment = aggregate(fetch(name))
                else:
                    sentiment = {
                        "sentiment_score": 0.0,
                        "sentiment_label": "unavailable",
                        "news_count": 0,
                        "sentiment_status": "not requested",
                    }

                prediction = predict(
                    prices,
                    sentiment.get("sentiment_score", 0.0),
                )

                result = {
                    **base,
                    **sentiment,
                    **prediction,
                }

        except Exception as exc:
            result = {
                **base,
                "status": "FAILED",
                "message": f"{type(exc).__name__}: {exc}",
            }

        results.append(result)

        print(
            f"[{index}/{total}] {name}: "
            f"{result.get('status', 'UNKNOWN')}"
        )

    output = pd.DataFrame(results)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    timestamped_file = PRED / f"predictions_{timestamp}.csv"
    latest_file = PRED / "predictions_latest.csv"

    output.to_csv(timestamped_file, index=False)
    output.to_csv(latest_file, index=False)

    print("\nSTATUS SUMMARY")
    if not output.empty and "status" in output.columns:
        print(output["status"].value_counts(dropna=False).to_string())
    else:
        print("No records were processed.")

    print(f"\nTimestamped report: {timestamped_file}")
    print(f"Latest report:      {latest_file}")


if __name__ == "__main__":
    main()
